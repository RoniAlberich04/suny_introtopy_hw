times = int(input('Enter a number: '))

print('****\n' * times)