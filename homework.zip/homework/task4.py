number = int(input('Enter a number: '))

if number // 1 and number // number: 
    print('This is a prime number')
else: 
    print('This is not a prime number')