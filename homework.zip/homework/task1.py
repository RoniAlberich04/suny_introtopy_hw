topay = float(input('Sum: '))
tax = float(input('Tax percentage: '))

result = topay + (topay * tax)/100

print('Result: ', result)